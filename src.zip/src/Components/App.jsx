import React from 'react';
import FormComp from './FormComp';

class App extends React.Component{
    render(){
        return(
            <div>
                <h3>Gowtham</h3>
                <FormComp />
            </div>
        );
    }
}

export default App;