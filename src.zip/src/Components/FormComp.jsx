import React from 'react';
import {Field,reduxForm} from 'redux-form';

class FormComp extends React.Component{
    displayHelper=(form)=>{
        return(
            
            <div className='form-group'>
                <label>{form.label}</label>
                <input className='form-control'
                {...form.input}
                
                />
                {form.meta.touched ? form.meta.error :''}
            </div>

        );
    }
    onGG=(val)=>{
        console.log(val);
    }
    render(){
        const {handleSubmit}=this.props;
        return(
            <form onSubmit={handleSubmit(this.onGG)}>
                <Field label='Title' name='title' component={this.displayHelper} />
                <Field label='Category' name='category' component={this.displayHelper} />
                <Field label='Details' name='details' component={this.displayHelper} />
                <button type='submit'>Submit</button>
            </form>

        );
    }
}

const validate=(form)=>{
    let errors={};
    if(!form.title){
        errors.title='enter the title';
    }
    if(!form.category){
        errors.category='enter the category'
    }
    if(!form.details){
        errors.details='enter the details'
    }
    return errors;
}
export default reduxForm({
    validate,
     form:'MyString'
})(FormComp);