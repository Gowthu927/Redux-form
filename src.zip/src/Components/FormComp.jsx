import React from 'react';
import {Field,reduxForm} from 'redux-form';

class FormComp extends React.Component{
    displayHelper=(form)=>{
        return(
            
            <div>
                {form.label}
                <input
                {...form.input}
                
                />
            </div>

        );
    }
    render(){
        return(
            <form>
                <Field label='Title' name='title' component={this.displayHelper} />
                <Field label='Category' name='category' component={this.displayHelper} />
                <Field label='Details' name='details' component={this.displayHelper} />
            </form>

        );
    }
}
export default reduxForm({
     form:'MyString'
})(FormComp);